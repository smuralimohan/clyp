package com.omnia.clypconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClypConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClypConfigApplication.class, args);
	}

}
