package com.ignis.clyp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClypApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClypApplication.class, args);
	}

}
